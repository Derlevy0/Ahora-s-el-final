from PyQt5.QtWidgets import QMainWindow, QDialog
from PyQt5 import uic

class Ventana_principal(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi("main_window.ui", self)
    def Botones_principal(self, info_handler, activity_handler, stats_handler, exit_handler):
        self.ui.info_button.clicked.connect(info_handler)
        self.ui.activity_button.clicked.connect(activity_handler)
        self.ui.stats_button.clicked.connect(stats_handler)
        self.ui.exit_button.clicked.connect(exit_handler)
class Ver_info(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi("info_window.ui", self)
    def Botones_ver(self, enter_info_handler, view_info_handler):
        self.ui.enter_info_button.clicked.connect(enter_info_handler)
        self.ui.view_info_button.clicked.connect(view_info_handler)
    def informacion(self, name, age, gender):
        self.ui.name_label.setText(f"Nombre: {name}")
        self.ui.age_label.setText(f"Edad: {age}")
        self.ui.gender_label.setText(f"Género: {gender}")
        
class Insertar_info(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ingresar_Info")
    def Ingresar(self):
        return {"nombre": self.name_input.text(), "edad": self.age_input.text(), "genero": self.gender_input.currentText()}
    def Ver(self):
        self.name_input.setText("")
        self.age_input.setText("")
        self.gender_input.setCurrentIndex(0)

class Ventana_juego(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi("game_window.ui", self)
        self.ui.buttons = [self.ui.button1, self.ui.button2, self.ui.button3, self.ui.button4]  # Actualiza según tus botones
    
    def Botones_juego(self, button_handlers):
        for i, btn in enumerate(self.ui.buttons):
            btn.clicked.connect(button_handlers[i])

    def Pregunta(self, question, colors):
        self.ui.question_label.setText(question)
        for i, color in enumerate(colors):
            self.ui.buttons[i].setText(color)

    def Respuesta(self):
        return self.ui.selected_color.text()


class Vnetana_resultados(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi("stats_window.ui", self)
    def Ver_grafica(self, df):
        # Aquí agregamos los gráficos con matplotlib.
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 2, figsize=(10, 5))

        ax[0].plot(df['Intentos'], df['Correctas'], label='Respuestas Correctas')
        ax[0].set_xlabel('Intentos')
        ax[0].set_ylabel('Correctas')
        ax[0].set_title('Intentos vs Correctas')
        ax[1].plot(df['Intentos'], df['Tiempo'], label='Tiempo', color='red')
        ax[1].set_xlabel('Intentos')
        ax[1].set_ylabel('Tiempo (segundos)')
        ax[1].set_title('Intentos vs Tiempo')
        
        plt.tight_layout()
        plt.show()