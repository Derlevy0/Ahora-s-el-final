import pandas as pd
import numpy as np
import os

class Paciente_modelo:
    def __init__(self):
        self.file_name = "patient_data.xlsx"
    def Guardar_paciente(self, name, age, gender):
        if os.path.exists(self.file_name):
            df = pd.read_excel(self.file_name)
        else:
            df = pd.DataFrame(columns=["Name", "Age", "Gender"])
            new_data = {"Name": name, "Age": age, "Gender": gender}
            df = df.append(new_data, ignore_index=True)
            df.to_excel(self.file_name, index=False)
    def Ver_paciente(self):
        if os.path.exists(self.file_name):
            df = pd.read_excel(self.file_name)
            return df.iloc[0] if not df.empty else None
        else:
            return None
        
class Modelo_juego:
     def __init__(self):
         self.file_name = "game_results.xlsx"
     def Guardar_resultados(self, correct_answers, attempts, time_taken):
         data = {"Correctas": [correct_answers], "Intentos": [attempts], "Tiempo": [time_taken]}
         df = pd.DataFrame(data)
         if os.path.exists(self.file_name):
             df_existing = pd.read_excel(self.file_name)
             df_existing = pd.concat([df_existing, df], ignore_index=True)
             df_existing.to_excel(self.file_name, index=False)
         else:
             df.to_excel(self.file_name, index=False)
     def Ver_resultados(self):
         if os.path.exists(self.file_name):
             return pd.read_excel(self.file_name)
         else:
             return pd.DataFrame(columns=["Correctas", "Intentos", "Tiempo"])
