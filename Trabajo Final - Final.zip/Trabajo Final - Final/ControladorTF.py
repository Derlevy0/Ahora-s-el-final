from PyQt5.QtWidgets import QApplication
import sys
import random
import time
from ModeloTF import Paciente_modelo, Modelo_juego
from VistaTF import Ventana_principal, Ver_info, Insertar_info, Ventana_juego, Vnetana_resultados

class Controller:
    def __init__(self):
        self.patient_model = Paciente_modelo()
        self.game_model = Modelo_juego()
        self.main_window = Ventana_principal()
        self.info_window = Ver_info()
        self.enter_info_window = Insertar_info()
        self.game_window = Ventana_juego()
        self.stats_window = Vnetana_resultados()
        self.main_window.Botones_principal(self.Abrir_Ventana_Info,
                                         self.Abrir_Ventana_Juego, self.Abrir_Ventana_Resultados, self.Salir)
        self.info_window.Botones_ver(self.Ventana_Paciente_Entrar,
                                         self.Ver_Paciente_Info)
        #self.game_window.Botones_juego(self.handle_game_answer)
       
    def Run(self):
        self.app = QApplication(sys.argv)
        self.main_window.show()
        sys.exit(self.app.exec_())
    def Abrir_Ventana_Info(self):
        self.info_window.show()
    def Abrir_Ventana_Juego(self):
        self.game_window.show()
    def Abrir_Ventana_Resultados(self):
        df = self.game_model.get_game_results()
        self.stats_window.plot_stats(df)
    def Salir(self):
        self.app.quit()
    def Ventana_Paciente_Entrar(self):
        self.enter_info_window.show()
    def Ver_Paciente_Info(self):
        info = self.patient_model.get_patient_info()
        if info is not None:
            self.info_window.display_patient_info(info['Name'], info['Age'], info['Gender'])
    def Guardar_Paciente_Info(self):
        data = self.enter_info_window.get_patient_data()
        self.patient_model.save_patient_info(data['name'], data['age'], data['gender'])
        self.enter_info_window.set_input_fields()
        self.enter_info_window.close()
    #def handle_game_answer(self, answer):
     #   correct_answer = self.game_window.get_answer()
      #  self.game_model.save_game_results(correct_answers, attempts, time_taken)
        
if __name__ == "__main__":
    Empezar = Controller()
    Empezar.Run()
    Empezar.Abrir_Ventana_Info()
    Empezar.Abrir_Ventana_Juego()
    Empezar.Abrir_Ventana_Resultados()
    Empezar.Salir()
    Empezar.Ventana_Paciente_Entrar()
    Empezar.Ver_Paciente_Info()
    Empezar.Guardar_Paciente_Info()
    